package pokedex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Startet das Backend
 */
@SpringBootApplication
public class PokedexApp {

    public static void main(String[] args) {
        SpringApplication.run(PokedexApp.class,args);
    }

}
